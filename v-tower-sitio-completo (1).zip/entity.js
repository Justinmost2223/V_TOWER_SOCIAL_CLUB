/* =========================================================================
   LEGAL IDENTITY OF THE SERVICE PROVIDER  (required by Art. 10 LSSI-CE and Art. 13 GDPR)
   Fill in the three values below, save, and re-deploy. They appear automatically in
   the Legal Notice and the Privacy Policy (in the pop-up viewer and the standalone pages).
   Example:  name: "Juan Pérez García",  taxId: "12345678Z",  address: "Calle Ejemplo 1, 28001 Madrid, Spain"
   ========================================================================= */
window.LEGAL_ENTITY={
  name:"",
  taxId:"",
  address:""
};
